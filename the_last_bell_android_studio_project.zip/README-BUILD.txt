THE LAST BELL — Android wrapper project

This is an Android Studio/Gradle project wrapping the existing game in a fullscreen Android WebView.
It is NOT a compiled APK yet.

EASIEST BUILD ROUTE (GitHub Actions):
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's Actions tab.
3. Run "Build Android APK" (or push to main).
4. Open the completed workflow run and download the "TheLastBell-debug-apk" artifact.
5. Extract the artifact; install app-debug.apk on your Android phone. You may need to allow installation from that source.

LOCAL BUILD:
Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Notes:
- Requires internet because the game loads Three.js from jsDelivr CDN.
- This is a debug APK for testing, not a Play Store release.
- A release APK should be signed with your own private signing key before distribution.
